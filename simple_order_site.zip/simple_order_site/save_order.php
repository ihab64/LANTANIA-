<?php
$data = json_decode(file_get_contents('php://input'), true);
$file = 'data/orders.json';
$orders = [];

if (file_exists($file)) {
    $orders = json_decode(file_get_contents($file), true);
}

$orders[] = $data;

file_put_contents($file, json_encode($orders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

http_response_code(200);
?>
